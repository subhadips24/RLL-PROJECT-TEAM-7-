import { QueryCustomer } from './query-customer';

describe('QueryCustomer', () => {
  it('should create an instance', () => {
    expect(new QueryCustomer()).toBeTruthy();
  });
});
