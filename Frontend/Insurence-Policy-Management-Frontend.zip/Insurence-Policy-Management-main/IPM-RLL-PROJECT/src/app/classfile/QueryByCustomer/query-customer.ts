export class QueryCustomer {


    qid!:number;
	

	 customeremail!:string;
	
	  qtopic!:string;
	
	  qdetails!:string;
	  qdate!:string
	  qanswer!:string
	  answerdate!:string
}
