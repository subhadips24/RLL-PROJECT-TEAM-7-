export class User {
      
      cid!:number;
      cname!:string
      cemail!:string
      cpassword!:string
      cphno!:string
      cage!:string
      cgender!:string
      caddress!:string
}
