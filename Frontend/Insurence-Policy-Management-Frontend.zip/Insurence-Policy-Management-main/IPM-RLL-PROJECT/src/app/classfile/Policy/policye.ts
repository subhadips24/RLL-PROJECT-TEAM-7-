export class Policye {

             pid!:number;
	
	      policyname!:string;

            policycatagory!:string;
	
            addDateOfPolicy!:string
}
