export class Unknownquery {

      usmsid!:number;
      usmsemail!:string;
	ucustomername!:string;
	 sms!:string;
	
}
