export class Admin {

      adminid!:number;
      adminemail!:string;
      adminname!:string;
      adminpassword!:string;
      adminphno!:string;
      adminage!:string;
      admingender!:string;
      adminaddress!:string;
      adminJoinDate!:string;
      seniormangeremail!:string;


}
